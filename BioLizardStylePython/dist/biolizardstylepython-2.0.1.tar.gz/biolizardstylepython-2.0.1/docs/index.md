```{include} ../README.md
```

```{toctree}
:maxdepth: 1
:hidden:

example.ipynb
plotly.ipynb
```