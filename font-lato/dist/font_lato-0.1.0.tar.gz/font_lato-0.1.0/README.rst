Fonts: Lato
================

Lato is a google font by Lukasz Dziedzic released under the OFL.

Preview: https://fonts.google.com/specimen/Lato

This font has been repackaged for the Python Fonts module: https://pypi.org/project/fonts/

Redistributed under the terms of the SIL Open Font License: https://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL