# BioLizardStylePython

Enhance plots with the signature Biolizard aesthetic for matplotlib and seaborn.

## Installation

The BioLizardStylePython package is available on PyPI and can be easily installed using:
```
pip install BioLizardStylePython
```

The BioLizardStylePython package makes use of the signature BioLizard font 'Red Hat Display'. This font can be found on Google Fonts under an open font license.
The font has been packaged using the [Python Fonts module](https://pypi.org/project/fonts/) and should be installed automatically when installing BioLizardStylePython. See [font-rhd](https://pypi.org/project/font-rhd/) for more information.

## Usage

### 1. Styling Function: `lizard_style()`

This function applies a BioLizard aesthetic to your matplotlib or seaborn plots. The aim is to ensure that plots maintain a uniform look, irrespective of whether they were made in R or Python.

### 2. BioLizard Color Palettes

These are qualitative, sequential, and divergent color maps that can be applied to your plots. The palettes are designed using BioLizard's house colors, keeping perceptual uniformity and color-blind friendliness in mind. For more information, consult the Usage & Examples page.

### 3. Finalizing and Exporting Plots: `finalise_lizardplot()`

This function adds a BioLizard footer beneath your graph and exports it to a specified format such as PNG or PDF. The footer includes the BioLizard logo at the bottom right corner and leaves room for source text.

## Contributing and Feedback

Contributions and feedback are very welcome and much appreciated. 

Issues can be reported [on github](https://github.com/lizard-bio/nature-grade-visualization-playground/issues).

